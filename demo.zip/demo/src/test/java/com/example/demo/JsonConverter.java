package com.example.demo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class JsonConverter {
    public static void main(String[] args) {

        String directoryPath = "/Users/zhubin/Downloads/env";
        File directory = new File(directoryPath);
        if (!directory.exists() || !directory.isDirectory()) {
            System.out.println("提供的路径不是一个有效的目录");
            return;
        }
        List<File> ymlFiles = new ArrayList<>();
        findYmlFiles(directory, ymlFiles);
        for (File file : ymlFiles) {
            convertYmlFile(file);
        }
    }

    private static void findYmlFiles(File directory, List<File> ymlFiles) {
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    findYmlFiles(file, ymlFiles);
                } else if (file.isFile() && file.getName().toLowerCase().endsWith(".yml")) {
                    ymlFiles.add(file);
                }
            }
        }
    }

    private static void convertYmlFile(File file) {
        StringBuilder fileContent = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                fileContent.append(line).append("\n");
            }
        } catch (IOException e) {
            System.err.println("读取文件 " + file.getName() + " 时出错: " + e.getMessage());
            return;
        }
        String content = fileContent.toString();
        String[] parts = content.split("binaryData:");
        if (parts.length < 2) {
            // 如果没有binaryData部分，直接复制文件
            copyFile(file, new File(file.getParentFile(), file.getName().replace(".yml", "2.yml")));
            return;
        }
        StringBuilder newContent = new StringBuilder(parts[0]).append("binaryData:\n");
        String binaryData = parts[1].trim();
        String[] dataEntries = binaryData.split("filename:");
        for (int i = 1; i < dataEntries.length; i++) {
            String entry = dataEntries[i].trim();
            String[] entryParts = entry.split("\n", 3);
            String filename = entryParts[0].trim();
            boolean base64enc = "true".equals(entryParts[1].trim().split(":")[1].trim());
            String jsonData = entryParts[2].trim();
            String convertedJson = convertJson(jsonData);
            newContent.append("  - filename: ").append(filename).append("\n");
            newContent.append("    base64enc: ").append(base64enc).append("\n");
            newContent.append("    data: |\n").append(convertedJson).append("\n");
        }
        File newFile = new File(file.getParentFile(), file.getName().replace(".yml", "2.yml"));
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(newFile))) {
            writer.write(newContent.toString());
            System.out.println("已成功转换并生成文件: " + newFile.getAbsolutePath());
        } catch (IOException e) {
            System.err.println("写入新文件 " + newFile.getName() + " 时出错: " + e.getMessage());
        }
    }

    private static String convertJson(String json) {
        try {
            JSONArray jsonArray;
            if (json.startsWith("[")) {
                jsonArray = new JSONArray(json);
            } else {
                jsonArray = new JSONArray().put(new JSONObject(json));
            }
            JSONObject common = new JSONObject();
            JSONObject authentication = new JSONObject();
            authentication.put("token_url", "https://sit-authn.idp.global.standardchartered.com/ns03/realms/internal-system/protocol/openid-connect/token");
            authentication.put("client_id", "test-jimmy-jwt");
            authentication.put("key_alias", "mydomain");
            common.put("authentication", authentication);
            JSONArray rules = new JSONArray();
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.getJSONObject(i);
                JSONObject match = obj.getJSONObject("match");
                JSONArray handlers = obj.getJSONArray("handlers");
                JSONObject rule = new JSONObject();
                rule.put("match", match);
                JSONArray newHandlers = new JSONArray();
                for (int j = 0; j < handlers.length(); j++) {
                    JSONObject handler = handlers.getJSONObject(j);
                    if ("tokenGenerator".equals(handler.getString("id"))) {
                        JSONObject newHandler = new JSONObject();
                        newHandler.put("id", "tokenGenerator");
                        newHandlers.put(newHandler);
                    } else {
                        newHandlers.put(handler);
                    }
                }
                rule.put("handlers", newHandlers);
                rules.put(rule);
            }
            JSONObject result = new JSONObject();
            result.put("common", common);
            result.put("rules", rules);
            return result.toString(4);
        } catch (JSONException e) {
            System.err.println("解析JSON时出错: " + e.getMessage());
            return json;
        }
    }

    private static void copyFile(File source, File target) {
        try (BufferedReader reader = new BufferedReader(new FileReader(source));
             BufferedWriter writer = new BufferedWriter(new FileWriter(target))) {
            String line;
            while ((line = reader.readLine()) != null) {
                writer.write(line);
                writer.newLine();
            }
            System.out.println("已成功复制文件: " + target.getAbsolutePath());
        } catch (IOException e) {
            System.err.println("复制文件 " + source.getName() + " 到 " + target.getName() + " 时出错: " + e.getMessage());
        }
    }
}
