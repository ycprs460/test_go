package com.example.demo;

import org.junit.jupiter.api.Test;

//@SpringBootTest
class DemoApplicationTests {

    @Test
    void contextLoads() {
        //convertYamlFilesInDirectory("/Users/zhubin/Downloads/env/catalyst-prod-hk");
    }
}
