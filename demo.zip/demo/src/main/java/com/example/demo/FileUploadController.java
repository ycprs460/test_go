package com.example.demo;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@RestController
public class FileUploadController {

    @PostMapping("/upload")
    public String uploadFile(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return "请选择要上传的文件";
        }
        try {
            // 这里简单将文件保存到项目根目录下，实际使用时可修改保存路径
            String filePath = "/Users/zhubin/Downloads" + File.separator + file.getOriginalFilename();
            File dest = new File(filePath);
            file.transferTo(dest);
            return "文件上传成功，保存路径：" + filePath;
        } catch (IOException e) {
            e.printStackTrace();
            return "文件上传失败：" + e.getMessage();
        }
    }
}
